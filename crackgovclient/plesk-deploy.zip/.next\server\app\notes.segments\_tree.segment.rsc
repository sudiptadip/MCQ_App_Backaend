:HL["/_next/static/chunks/3d-1vk5hzu5rq.css","style"]
:HL["/_next/static/chunks/37my8zin522za.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/logo.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"notes","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"rOhsfPhahyG9SOvZvTnf0"}
