module.exports=[63716,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice_history_page_actions_1e0t_2f.js.map