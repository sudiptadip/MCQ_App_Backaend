globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/VGBVpTlQ4FeaP_DSSKzzy/_buildManifest.js",
    "static/VGBVpTlQ4FeaP_DSSKzzy/_ssgManifest.js",
    "static/VGBVpTlQ4FeaP_DSSKzzy/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3mc6dra1m0098.js",
    "static/chunks/2i51e627rllld.js",
    "static/chunks/1rj7ns8rte9vc.js",
    "static/chunks/2u2a6doy3k2o_.js",
    "static/chunks/turbopack-1c0mjrh_wh1zo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
