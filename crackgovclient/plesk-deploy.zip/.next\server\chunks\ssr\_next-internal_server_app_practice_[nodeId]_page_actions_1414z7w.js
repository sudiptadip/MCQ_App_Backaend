module.exports=[46008,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice_%5BnodeId%5D_page_actions_1414z7w.js.map