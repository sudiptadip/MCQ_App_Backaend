:HL["/_next/static/chunks/3d-1vk5hzu5rq.css","style"]
:HL["/_next/static/chunks/37my8zin522za.css","style"]
:HL["/logo.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":4112,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4160,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"rOhsfPhahyG9SOvZvTnf0"}
