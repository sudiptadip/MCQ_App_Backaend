module.exports=[94197,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice_custom_page_actions_025dwho.js.map