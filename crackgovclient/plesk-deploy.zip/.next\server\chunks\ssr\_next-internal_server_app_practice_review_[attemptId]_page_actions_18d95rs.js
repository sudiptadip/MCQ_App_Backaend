module.exports=[63149,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice_review_%5BattemptId%5D_page_actions_18d95rs.js.map