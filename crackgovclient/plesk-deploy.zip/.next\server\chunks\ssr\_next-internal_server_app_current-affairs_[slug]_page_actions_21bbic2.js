module.exports=[66419,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_current-affairs_%5Bslug%5D_page_actions_21bbic2.js.map