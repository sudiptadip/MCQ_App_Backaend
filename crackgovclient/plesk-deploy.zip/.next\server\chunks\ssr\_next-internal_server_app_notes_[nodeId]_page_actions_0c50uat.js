module.exports=[70981,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_notes_%5BnodeId%5D_page_actions_0c50uat.js.map