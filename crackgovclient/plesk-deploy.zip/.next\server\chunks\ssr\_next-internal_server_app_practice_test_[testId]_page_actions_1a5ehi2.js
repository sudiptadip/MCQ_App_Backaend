module.exports=[3510,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice_test_%5BtestId%5D_page_actions_1a5ehi2.js.map