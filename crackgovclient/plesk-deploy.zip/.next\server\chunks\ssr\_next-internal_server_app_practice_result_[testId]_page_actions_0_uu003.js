module.exports=[30878,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_practice_result_%5BtestId%5D_page_actions_0_uu003.js.map