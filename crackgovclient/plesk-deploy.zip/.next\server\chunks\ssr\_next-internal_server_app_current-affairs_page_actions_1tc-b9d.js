module.exports=[55757,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_current-affairs_page_actions_1tc-b9d.js.map